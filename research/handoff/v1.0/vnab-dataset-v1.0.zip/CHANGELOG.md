# Changelog

## v1.0

- Hợp nhất pilot đã duyệt và ứng viên batch đã duyệt. Ba P0 dùng chung chỉ xuất một lần.
- Giữ split đã bàn giao của pilot và mọi mẫu liên kết theo nhóm, ID hay bằng chứng.
- Xuất MRC theo schema v1.1 có tám trường metadata.
- Loại hai revise và mười reject. Cách ly năm mapping sai nhãn khỏi release.
