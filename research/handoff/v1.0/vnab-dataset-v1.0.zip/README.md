# VNAB v1.0

Train/dev dùng để phát triển. Mẫu pilot đã dùng để điều chỉnh pipeline thuộc dữ liệu phát triển.

Chạy từ thư mục đã giải nén.

```python
from datasets import load_dataset
mrc = load_dataset("json", data_files={"train": "mrc_train.jsonl", "validation": "mrc_dev.jsonl"})
qa = load_dataset("json", data_files={"train": "qa_train.jsonl", "validation": "qa_dev.jsonl"})
```

JSONL UTF-8. MRC schema v1.1 giữ id, question, context, answers.text và answers.answer_start theo bản ghi phẳng SQuAD. Offset là chỉ số ký tự Unicode Python từ 0 trong context nguyên văn. Metadata kế thừa Full QA gồm group_id, province, type, source_doc, article_clause, context_origin, answerable và review_status. Full QA còn giữ các ID, provenance, quan hệ và audit review. Manifest ghi split và hash nội dung. Gói chứa văn bản UTF-8 để Thư tự tokenize bằng AutoTokenizer với use_fast=True.
