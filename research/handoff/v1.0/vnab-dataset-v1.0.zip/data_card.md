# Dataset địa giới VNAB v1.0

Nguồn là snapshot v1.0 từ tám workbook Excel mapping và chín TXT nghị quyết. Kiểm chứng có hỗ trợ AI, do Vi xem xét và xác nhận. Metadata điều khoản của mẫu mapping đã duyệt được giữ trong reviewer_note; context_origin của các mẫu này vẫn là mapping. Bộ có 249 Full QA và 163 MRC. MRC thiên về T1.

Benchmark lịch sử gồm hai phiên bản matrix và các lượt pilot, batch khác nhau. Provenance lịch sử chưa đầy đủ và có 110 lượt chưa nhận diện được nhóm. Test chính và challenge phải báo cáo riêng. Một số nhóm challenge có tín hiệu lịch sử. Pilot đã dùng để điều chỉnh pipeline thuộc dữ liệu phát triển.

Cách ly hai QA revise ở review rank 235 và 239 do nguồn gán toan_bo cho đơn vị không sắp xếp. Rà năm dòng nguồn liên quan ở Điều 1 khoản 164 và giữ nguyên snapshot gốc. Mười QA reject bị loại vì trùng mapping, đáp án và bằng chứng với pilot đã duyệt.
